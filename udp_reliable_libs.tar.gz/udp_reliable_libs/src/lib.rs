use std::fs;
use laminar::Config;
use mio::net::UdpSocket;
use rudp::UdpLike;
use tokio_kcp::{KcpConfig, KcpNoDelayConfig};
use serde::Deserialize;

pub mod telemetry;

pub const CHANNEL_ID: u8 = 1;
pub const CLIENT_ID: u64 = 2;
pub const PROTOCOL_ID: u64 = 3;

pub fn get_kcp_config() -> KcpConfig {
    let mut config = KcpConfig::default();
    config.nodelay = KcpNoDelayConfig::normal();
    config.flush_write = true;
    config.flush_acks_input = true;
    config.stream = true;
    config
}

pub fn get_laminar_config() -> Config {
    let config = Config::default();
    //config.idle_connection_timeout = Duration::from_secs(10);
    //config.heartbeat_interval = Some(Duration::from_secs(10));
    config
}

#[derive(Deserialize, Debug)]
pub struct BenchConfig {
    pub common: CommonConfig,
}

#[derive(Deserialize, Debug)]
pub struct CommonConfig {
    pub number_of_messages: u64,
    pub server: String,
    pub client: String,
}

impl BenchConfig {
    pub fn init() -> Self {
        let file = "./conf/cfg.toml";
        let content =
            fs::read_to_string(file).unwrap();
        let config: BenchConfig = toml::from_str(content.as_str()).unwrap();

        config
    }
}

pub struct SocketWrapper {
    socket: UdpSocket
}

impl SocketWrapper {
    pub fn new(socket: UdpSocket) -> Self {
        SocketWrapper {
            socket
        }
    }
}

impl UdpLike for SocketWrapper {
    fn send(&mut self, buf: &[u8]) -> std::io::Result<usize> {
        self.socket.send(buf)
    }

    fn recv(&mut self, buf: &mut [u8]) -> std::io::Result<usize> {
        self.socket.recv(buf)
    }
}