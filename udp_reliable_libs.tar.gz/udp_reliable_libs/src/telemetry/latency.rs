use std::thread;
use std::thread::JoinHandle;
use std::time::{SystemTime, UNIX_EPOCH};
use crossbeam_channel::Sender;
use hdrhistogram::Histogram;
use crate::BenchConfig;

pub struct LatencyMonitory {
    hist: Histogram<u64>,
}

impl LatencyMonitory {
    pub fn new() -> Self {
        let hist = Histogram::<u64>::new_with_bounds(1, 60 * 60 * 1000 * 1000, 3).unwrap();
        LatencyMonitory { hist }
    }

    pub fn start(mut self) -> (JoinHandle<()>, Sender<u128>) {
        let cfg = BenchConfig::init();

        let (latency_tx, latency_rx) = crossbeam_channel::unbounded::<u128>();

        let mut not_warm_up = false;
        let latency_handler = thread::spawn( move || {
            loop {
                match latency_rx.recv() {
                    Ok(ts) => {
                        if let Err(e) = self.hist.record(ts as u64) {
                            eprintln!("failed to record latency: {}", e);
                        }
                    }
                    Err(e) => println!("unknown message received: {}", e),
                }

                if self.hist.len() == cfg.common.number_of_messages / 2 {
                    println!("=============== latencies in micros ===============");
                    self.log_latencies();
                    println!("=============== latency reset ===============");
                    self.hist.reset();

                    if not_warm_up {
                        break;
                    }
                    not_warm_up = true;
                }
            }

        });

        // let latency_tx_clone = latency_tx.clone();
        // let tick = crossbeam_channel::tick(Duration::from_secs(10));
        // thread::spawn(move || {
        //     loop {
        //         if tick.recv().is_ok() {
        //             if let Err(e) = latency_tx_clone.send(LatencyMessage::LogLatencies) {
        //                 error!("failed to send latency message LogLatencies: {}", e);
        //             }
        //         }
        //     }
        // });

        (latency_handler, latency_tx)
    }

    fn log_latencies(&self) {
        latencies(&self.hist);
    }
}

fn latencies(hist: &Histogram<u64>) {
    println!("len: {}, 50({}), 90({}), 99({}), 99.9({}), 99.99({}), max({})",
        hist.len(),
        hist.value_at_quantile(0.50),
        hist.value_at_quantile(0.90),
        hist.value_at_quantile(0.99),
        hist.value_at_quantile(0.999),
        hist.value_at_quantile(0.9999),
        hist.max());
}

pub fn get_epoch_millis() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_millis()
        .try_into()
        .unwrap()
}

pub fn get_epoch_micros() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_micros()
        //.try_into()
        //.unwrap()
}