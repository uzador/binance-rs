# udp_reliable_libs

## Description
Project aim is to compare different crates providing reliability and guarantees on top of UDP.

### laminar
https://crates.io/crates/laminar
```
cargo r --bin laminar-server 
cargo r --bin laminar-client
```

### tokio_kcp
https://crates.io/crates/tokio_kcp
```
cargo r --bin kcp-server
cargo r --bin kcp-client
```

### enet
https://crates.io/crates/enet
```
cargo r --bin enet-server
cargo r --bin enet-client
```

### rudp
https://crates.io/crates/rudp
```
cargo r --bin rudp-server
cargo r --bin rudp-client
```

### renet
https://crates.io/crates/renet
```
cargo r --bin renet-server
cargo r --bin renet-client
```

### tachyon-networking (issue with compilation)
https://github.com/gamemachine/tachyon-networking